import  Navbar from "../componenets/Navbar";
import  Hero from "../componenets/Hero";

function LandingPage() {
  return (
    <>
      {/* Navigation Bar */}
      <Navbar />

      {/* Hero Section */}
      <Hero />

      {/* About Section */}
      {/* <About /> */}

      {/* Creators Section */}
      {/* <Creators /> */}

      {/* Footer Section */}
      {/* <Footer /> */}
    </>
  );
}

export default LandingPage;