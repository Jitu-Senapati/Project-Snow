function LoginPage() {
    return (
        <>
            <h1>Login Page</h1>
        </>
    );
}

export default LoginPage;