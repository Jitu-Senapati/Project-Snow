// components/Footer.jsx
// Bottom footer section

function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 STUVO 5. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
